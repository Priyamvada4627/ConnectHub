from . import models
from fastapi import FastAPI
from .database import engine
from .routers import post, user, auth, vote, comment, follow, message, chat,profile,feed,notification
from .config import settings
from fastapi.middleware.cors import CORSMiddleware

app = FastAPI(
    title="Resume Ready API",
    description="Social platform backend with posts, messaging, and real-time chat.",
    version="1.0.0",
)

ALLOWED_ORIGINS = getattr(settings, "allowed_origins", None) or [
    "http://localhost:3000",
    "http://localhost:5500",
    "http://127.0.0.1:5500",
]

app.add_middleware(
    CORSMiddleware,
    allow_origins=ALLOWED_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(post.router)
app.include_router(user.router)
app.include_router(auth.router)
app.include_router(vote.router)
app.include_router(comment.router)
app.include_router(follow.router)
app.include_router(message.router)
app.include_router(chat.router)
app.include_router(profile.router)
app.include_router(feed.router)
app.include_router(notification.router)


@app.get("/", tags=["Health"])
async def root():
    return {"status": "ok", "message": "Resume Ready API is running"}
